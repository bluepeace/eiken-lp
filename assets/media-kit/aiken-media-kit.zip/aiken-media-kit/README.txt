﻿AiKen（アイケン）メディア向け素材
====================================

英検対策アプリ AiKen の紹介用素材です。

aiken-media-guide.pdf   ご紹介資料（PDF）
01_logo                 ロゴ
02_screens_smartphone   スマートフォンのアプリ画面
03_screens_tablet       タブレット（幅の広い画面）のアプリ画面
04_store_images         App Store / Google Play に掲載している紹介画像
05_ai_scoring           AI添削（英検2級ライティング）とスピーキング（英検3級）の画面
06_buddies              バディ10匹（マメ、チョコ、コロ、モコ、マロン、シロ、ティア、ルーク、ソラ、ジン）

・画面はすべて実際のアプリの画面です。
・画面に写っている名前、日付、学習記録はサンプルです。
・AI添削の点数は1つの答案の結果で、平均点や合格の目安ではありません。
・料金が写った画面は含めていません。最新の料金は https://aiken.life/plan をご覧ください。

サービスの基本情報: https://aiken.life/media
お問い合わせ: info@aiken.life ／ https://aiken.life/contact
運営: Bluepiece Lab.
